package com.example.demo.domain.topicos;

public enum Estado {
    ENVIADO,
    RECIBIDO,
    ANULADO
}
