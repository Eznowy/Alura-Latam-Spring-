package com.example.demo.domain.topicos.validaciones;

import com.example.demo.domain.topicos.DatosCrearTopico;

public interface ValidadorDeTopicos {
    public void validar(DatosCrearTopico datos);
}
