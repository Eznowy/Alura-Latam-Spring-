package com.example.demo.infra.security;

public record DatosJWTtoken(String token) {
}
