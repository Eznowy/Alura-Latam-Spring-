package com.example.demo.domain.usuarios;

public record DatosAutenticacionUsuario(String login, String clave) {

}
